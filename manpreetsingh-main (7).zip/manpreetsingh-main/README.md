# manpreetsingh

Created a portfolio website for my classmate who has career objective to become a successfull data scientist.
This project is created only using Html, Css, Javascript and Bootstrap.

LIVE LINK := https://manpreetsingh.pages.dev/
